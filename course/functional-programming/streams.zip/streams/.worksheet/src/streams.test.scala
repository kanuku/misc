package streams

object test {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(74); 
  println("Welcome to the Scala worksheet");$skip(20); 
  val a=List(1,2,3);System.out.println("""a  : List[Int] = """ + $show(a ));$skip(7); val res$0 = 
  5::a;System.out.println("""res0: List[Int] = """ + $show(res$0))}
}
